const request = require('supertest');
const app = require('../src/app');

describe('Products API', () => {
  test('GET /products returns all products', async () => {
    const res = await request(app).get('/products');
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  test('GET /products?category=electronics filters correctly', async () => {
    const res = await request(app).get('/products?category=electronics');
    expect(res.status).toBe(200);
    expect(res.body.every(p => p.category === 'electronics')).toBe(true);
  });

  test('GET /products/:id returns a product', async () => {
    const res = await request(app).get('/products/1');
    expect(res.status).toBe(200);
    expect(res.body.name).toBe('Wireless Headphones');
  });

  test('GET /products/:id returns 404 for missing product', async () => {
    const res = await request(app).get('/products/999');
    expect(res.status).toBe(404);
  });
});

describe('Auth API', () => {
  test('POST /auth/register creates a new user', async () => {
    const res = await request(app).post('/auth/register').send({ email: 'new@test.com', password: 'abc123' });
    expect(res.status).toBe(201);
  });

  test('POST /auth/register rejects duplicate email', async () => {
    await request(app).post('/auth/register').send({ email: 'dup@test.com', password: 'abc' });
    const res = await request(app).post('/auth/register').send({ email: 'dup@test.com', password: 'abc' });
    expect(res.status).toBe(409);
  });

  test('POST /auth/login succeeds with correct credentials', async () => {
    const res = await request(app).post('/auth/login').send({ email: 'user@shopeasy.com', password: 'pass123' });
    expect(res.status).toBe(200);
    expect(res.body.token).toBeDefined();
  });

  // BUG #1009: This test FAILS because login returns 200 instead of 401
  test('BUG #1009: POST /auth/login should return 401 on wrong password', async () => {
    const res = await request(app).post('/auth/login').send({ email: 'user@shopeasy.com', password: 'WRONG' });
    expect(res.status).toBe(401); // FAILS — currently returns 200
  });
});

describe('Cart API', () => {
  test('POST /cart adds item to cart', async () => {
    const res = await request(app).post('/cart').send({ productId: 1, quantity: 2 });
    expect(res.status).toBe(201);
  });

  test('POST /cart rejects out-of-stock quantity', async () => {
    const res = await request(app).post('/cart').send({ productId: 2, quantity: 999 });
    expect(res.status).toBe(400);
  });

  // BUG #1008: This test FAILS because coupon discount is calculated incorrectly
  test('BUG #1008: GET /cart/total applies 10% coupon correctly', async () => {
    await request(app).post('/cart').send({ productId: 3, quantity: 1 });
    const res = await request(app).get('/cart/total?coupon=SAVE10');
    expect(res.body.total).toBeGreaterThan(0); // FAILS — total goes negative
  });
});

describe('Search API', () => {
  test('GET /search returns matching products', async () => {
    const res = await request(app).get('/search?q=headphones');
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  // BUG #1011: This test FAILS — special chars crash the RegExp
  test('BUG #1011: GET /search handles special characters gracefully', async () => {
    const res = await request(app).get('/search?q=(invalid+regex[');
    expect(res.status).toBe(200); // FAILS — throws 500
    expect(Array.isArray(res.body)).toBe(true);
  });
});

describe('Wishlist API', () => {
  test('POST /wishlist adds product', async () => {
    const res = await request(app).post('/wishlist').send({ productId: 1 });
    expect(res.status).toBe(201);
  });

  test('POST /wishlist does not duplicate items', async () => {
    await request(app).post('/wishlist').send({ productId: 2 });
    const res = await request(app).post('/wishlist').send({ productId: 2 });
    expect(res.body.filter(i => i.productId === 2).length).toBe(1);
  });
});
