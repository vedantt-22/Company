# ShopEasy — Azure DevOps Step-by-Step Setup Guide

## Prerequisites
- Azure DevOps account (free at dev.azure.com)
- Git installed locally
- Node.js 18+ installed

---

## STEP 1 — Create Azure DevOps Project

1. Go to https://dev.azure.com
2. Click **"New project"** (top right)
3. Fill in:
   - Project name: `ShopEasy`
   - Visibility: Private
   - Version control: Git
   - Work item process: **Scrum** ← important!
4. Click **Create**

---

## STEP 2 — Push this code to Azure Repos

```bash
# Initialize git in this folder
git init
git add .
git commit -m "Initial commit: ShopEasy API with known bugs"

# Add your Azure DevOps remote (replace <org> and <project>)
git remote add origin https://<org>@dev.azure.com/<org>/ShopEasy/_git/ShopEasy

# Push
git push -u origin main
```

---

## STEP 3 — Create Work Items (Backlog)

In Azure DevOps → Boards → Backlogs:

1. Create Epic: "ShopEasy MVP Launch"
2. Create User Stories (see WORK_ITEMS.md)
3. Create Bugs (see WORK_ITEMS.md)
4. Set Story Points and Sprints

---

## STEP 4 — Create Sprint 1

1. Boards → Sprints → "New Sprint"
2. Name: Sprint 1, Dates: (pick 2 weeks from today)
3. Drag stories and bugs onto Sprint 1
4. Set team capacity

---

## STEP 5 — Set up CI/CD Pipeline

1. Pipelines → Create Pipeline
2. Choose: **Azure Repos Git**
3. Select: **ShopEasy** repo
4. Choose: **Existing Azure Pipelines YAML file**
5. Select: `/azure-pipelines.yml`
6. Click **Run** — watch it build!

---

## STEP 6 — Fix a Bug (hands-on practice)

### Fix Bug #1009 (Login returns 200 instead of 401):

In `src/app.js`, find:
```javascript
return res.json({ message: 'Login failed' });
```
Change to:
```javascript
return res.status(401).json({ message: 'Login failed' });
```

Then:
```bash
git checkout -b bugfix/1009-login-status-code
git add src/app.js
git commit -m "Fix #1009: Return 401 on failed login"
git push origin bugfix/1009-login-status-code
```

Create a Pull Request in Azure DevOps → Repos → Pull Requests
Watch the pipeline run automatically on your PR!

---

## STEP 7 — Create Environments with Approval Gates

1. Pipelines → Environments → New environment
2. Name: `shopeasy-staging`, Resource: None
3. Name: `shopeasy-production`, Resource: None
4. On `shopeasy-production` → click "..." → Approvals and checks
5. Add → Approvals → add yourself as approver
6. Now your production deploy requires your manual OK!
