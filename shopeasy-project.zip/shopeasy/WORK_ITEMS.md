# ShopEasy — Azure DevOps Work Items
# ============================================================
# Use this file to manually create these items in Azure DevOps
# or as reference while following the step-by-step guide.
# ============================================================

# ============================================================
# EPIC
# ============================================================
Epic #1000: ShopEasy MVP Launch
  Description: Build and ship the first version of the ShopEasy
               e-commerce platform with core shopping features.

# ============================================================
# USER STORIES (under Epic #1000)
# ============================================================

Story #1001: Product browsing & filtering
  As a shopper, I want to filter products by category
  so that I can quickly find what I'm looking for.

  Acceptance Criteria:
  - [ ] Filter by category (electronics, footwear, kitchen)
  - [ ] URL param ?category= works correctly
  - [ ] Returns empty array (not error) when no results
  Story Points: 8
  Sprint: Sprint 1
  State: Active

---

Story #1004: Password reset
  As a user, I want to reset my password via email
  so that I can regain access to my account.

  Acceptance Criteria:
  - [ ] POST /auth/reset-password accepts email
  - [ ] Returns 200 even if email not found (security)
  - [ ] Token expires after 1 hour
  Story Points: 5
  Sprint: Sprint 1
  State: New

---

Story #1005: Wishlist
  As a shopper, I want to save products to a wishlist
  so that I can buy them later.

  Acceptance Criteria:
  - [ ] POST /wishlist adds a product
  - [ ] Duplicate products are not added twice
  - [ ] GET /wishlist returns all saved items
  Story Points: 5
  Sprint: Sprint 1
  State: In Review

---

Story #1000: User registration
  As a new visitor, I want to register an account
  so that I can make purchases and track orders.

  Acceptance Criteria:
  - [x] POST /auth/register creates a user
  - [x] Duplicate emails return 409
  - [x] Missing fields return 400
  Story Points: 3
  Sprint: Sprint 1
  State: Done

# ============================================================
# TASKS (child of stories)
# ============================================================

Task #1002: Design filter UI component
  Parent: Story #1001
  Assigned To: Dev Team
  Remaining Work: 4h
  State: Active

Task #1003: Set up project repo and CI pipeline
  Parent: Epic #1000
  Remaining Work: 0h
  State: Done

# ============================================================
# BUGS
# ============================================================

Bug #1008: Cart total shows wrong price after coupon applied
  Severity: 1 - Critical
  Priority: 1
  Repro Steps:
    1. POST /cart with { productId: 3, quantity: 1 } (price = 1999)
    2. GET /cart/total?coupon=SAVE10
    3. Expected: total = 1799.1 (10% off)
    4. Actual: total = -199.9 (negative! coupon multiplier is 1.1 not 0.1)
  Root Cause: In app.js line ~45, `total * 1.1` should be `total * 0.1`
  Fix: Change `total = total - total * 1.1` to `total = total - total * 0.1`
  Sprint: Sprint 1
  State: New
  Linked To: Story #1001

---

Bug #1009: Login fails silently — returns HTTP 200 on wrong password
  Severity: 1 - Critical
  Priority: 1
  Repro Steps:
    1. POST /auth/login with { email: "user@shopeasy.com", password: "WRONG" }
    2. Expected: HTTP 401 Unauthorized
    3. Actual: HTTP 200 with { message: "Login failed" }
  Root Cause: res.json() used instead of res.status(401).json()
  Fix: Change `return res.json(...)` to `return res.status(401).json(...)`
  Sprint: Sprint 1
  State: Active
  Linked To: Story #1000

---

Bug #1010: Product images broken on Safari mobile
  Severity: 2 - High
  Priority: 2
  Repro Steps:
    1. Open any product page on Safari iOS 16+
    2. Expected: Product image loads correctly
    3. Actual: Image shows broken icon
  Root Cause: Missing WebP fallback — Safari older versions don't support WebP
  Fix: Add <picture> element with JPEG fallback in frontend
  Sprint: Sprint 1
  State: In Review

---

Bug #1011: Search API crashes on special characters
  Severity: 2 - High
  Priority: 2
  Repro Steps:
    1. GET /search?q=(invalid+regex[
    2. Expected: HTTP 200 with empty results array
    3. Actual: HTTP 500 — Uncaught RegExp syntax error
  Root Cause: new RegExp(q) throws when q contains regex special chars
  Fix: Wrap in try/catch OR escape the query string before creating RegExp
  Sprint: Sprint 1
  State: New
  Linked To: Story — Search feature
