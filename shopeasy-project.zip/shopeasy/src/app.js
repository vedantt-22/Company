const express = require('express');
const app = express();

app.use(express.json());

// --- Products ---
let products = [
  { id: 1, name: 'Wireless Headphones', price: 2999, category: 'electronics', stock: 10 },
  { id: 2, name: 'Running Shoes', price: 4999, category: 'footwear', stock: 5 },
  { id: 3, name: 'Coffee Maker', price: 1999, category: 'kitchen', stock: 8 },
];

app.get('/products', (req, res) => {
  const { category } = req.query;
  if (category) {
    return res.json(products.filter(p => p.category === category));
  }
  res.json(products);
});

app.get('/products/:id', (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id));
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json(product);
});

// --- Cart ---
let cart = [];

app.get('/cart', (req, res) => res.json(cart));

app.post('/cart', (req, res) => {
  const { productId, quantity } = req.body;
  const product = products.find(p => p.id === productId);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  if (quantity > product.stock) return res.status(400).json({ error: 'Insufficient stock' });

  const existing = cart.find(i => i.productId === productId);
  if (existing) {
    existing.quantity += quantity;
  } else {
    cart.push({ productId, name: product.name, price: product.price, quantity });
  }
  res.status(201).json(cart);
});

// BUG #1008: coupon discount not applied correctly
app.get('/cart/total', (req, res) => {
  const { coupon } = req.query;
  let total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  // BUG: discount multiplier is wrong — should be 0.9 for 10% off
  if (coupon === 'SAVE10') total = total - total * 1.1;
  res.json({ total, coupon: coupon || null });
});

// --- Auth ---
const users = [{ id: 1, email: 'user@shopeasy.com', password: 'pass123' }];

// BUG #1009: login fails silently on wrong password — returns 200 instead of 401
app.post('/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);
  if (!user || user.password !== password) {
    return res.json({ message: 'Login failed' }); // BUG: should be res.status(401)
  }
  res.json({ token: 'fake-jwt-token', userId: user.id });
});

app.post('/auth/register', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  if (users.find(u => u.email === email)) return res.status(409).json({ error: 'User already exists' });
  const newUser = { id: users.length + 1, email, password };
  users.push(newUser);
  res.status(201).json({ userId: newUser.id });
});

// --- Wishlist ---
let wishlist = [];

app.get('/wishlist', (req, res) => res.json(wishlist));

app.post('/wishlist', (req, res) => {
  const { productId } = req.body;
  const product = products.find(p => p.id === productId);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  if (!wishlist.find(i => i.productId === productId)) {
    wishlist.push({ productId, name: product.name, price: product.price });
  }
  res.status(201).json(wishlist);
});

// --- Search ---
// BUG #1011: special characters break search
app.get('/search', (req, res) => {
  const { q } = req.query;
  // BUG: no try/catch — RegExp constructor throws on invalid special chars
  const regex = new RegExp(q, 'i');
  const results = products.filter(p => regex.test(p.name));
  res.json(results);
});

module.exports = app;
