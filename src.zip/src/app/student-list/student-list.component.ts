import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { StudentService } from '../shared/services/Students/student.service';
import { StudentItem } from '../student-item/student-item';
import { FilterByPerformancePipePipe } from '../shared/pipes/FilterByPerformance/filter-by-performance-pipe.pipe';

@Component({
  selector: 'app-student-list',
  standalone: true,
  // Fixed the double comma error here
  imports: [
    CommonModule, 
    RouterModule, 
    FormsModule,
    StudentItem,
    FilterByPerformancePipePipe
  ],
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  students: any[] = [];
  filterType: string = 'all';

  private studentService = inject(StudentService);
  private router = inject(Router);

  ngOnInit() {
    this.students = this.studentService.getStudents();
  }

  handleDelete(id: number) {
    if(confirm('Delete this student?')) {
      this.studentService.deleteStudent(id);
      // Refresh list
      this.students = [...this.studentService.getStudents()];
    }
  }

  handleView(id: number) {
    this.router.navigate(['/student', id]);
  }
}