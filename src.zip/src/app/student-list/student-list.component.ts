import { Component, OnInit } from '@angular/core';
import { Student } from '../shared/studentModals';
import { StudentService } from '../shared/services/Students/student.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FilterByPerformancePipePipe } from '../shared/pipes/FilterByPerformance/filter-by-performance-pipe.pipe';
@Component({
  selector: 'app-student-list',
  imports: [ CommonModule, FormsModule],
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.css'
})
export class StudentListComponent implements OnInit{
  students: Student[] = [];
  filterStatus: string = 'all';
  constructor(private studentService: StudentService) {}
  ngOnInit(): void {
    this.students = this.studentService.getStudents();
  }

  deleteStudent(id: number) {
    this.studentService.deleteStudent(id);

    this.students = this.studentService.getStudents();
  }

  trackById(index: number, student: Student) {
    return student.id;
  }
}

