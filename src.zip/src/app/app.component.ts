import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { StudentListComponent } from "./student-list/student-list.component";
import { StudentCardComponent } from "./student-card/student-card.component";

@Component({
  selector: 'app-root',
  imports: [RouterModule, StudentListComponent, StudentCardComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'grade';
}
