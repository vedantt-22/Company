import { Component, OnInit, inject } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../shared/services/Students/student.service';
import { Student } from '../shared/studentModals';



@Component({
  selector: 'app-grade-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="form-container" *ngIf="student">
      <h2>Add Grade for {{ student.name }}</h2>
      
      <form (ngSubmit)="saveGrade()" #gradeForm="ngForm">
        
        <div class="form-group">
          <label>Subject</label>
          <select [(ngModel)]="subject" name="subject" required class="form-control">
            <option value="" disabled selected>Select a Subject</option>
            <option *ngFor="let sub of subjects" [value]="sub">{{ sub }}</option>
          </select>
        </div>

        <div class="form-group">
          <label>Score (0-100)</label>
          <input 
            type="number" 
            [(ngModel)]="score" 
            name="score" 
            required 
            min="0" 
            max="100" 
            class="form-control"
            #scoreInput="ngModel"
          >
          <div *ngIf="scoreInput.invalid && scoreInput.touched" class="error-msg">
            Score must be between 0 and 100.
          </div>
        </div>

        <div class="actions">
          <button type="button" (click)="cancel()" class="btn-secondary">Cancel</button>
          <button type="submit" class="btn-primary" [disabled]="gradeForm.invalid">
            Submit Grade
          </button>
        </div>
      </form>
    </div>
  `,
  styles: [`
    .form-container { max-width: 500px; margin: 30px auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px; background: #fff; }
    .form-group { margin-bottom: 20px; }
    .form-control { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
    .error-msg { color: #dc3545; font-size: 0.85rem; }
    .actions { display: flex; justify-content: flex-end; gap: 10px; }
    .btn-primary { background: #28a745; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
    .btn-primary:disabled { background: #ccc; }
    .btn-secondary { background: #6c757d; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
  `]
})
export class GradeFormComponent implements OnInit {
  student: Student | undefined;
  subject: string = '';
  score: number | null = null;
  
  // Predefined subjects for the dropdown
  subjects = ['Math', 'Physics', 'Chemistry', 'History', 'Literature', 'Biology', 'Computer Science'];

  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private location = inject(Location);
  private studentService = inject(StudentService);

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (id) {
      this.student = this.studentService.getStudentById(id);
    }
  }

  saveGrade() {
    if (this.student && this.score !== null && this.subject) {
      const newGrade = {
        subject: this.subject,
        score: this.score,
        date: new Date()
      };
      
      this.studentService.addGrade(this.student.id, newGrade);
      this.cancel(); // Go back to the previous page
    }
  }

  cancel() {
    this.location.back();
  }
}