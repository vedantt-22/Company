import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Student } from '../shared/studentModals';
@Component({
  selector: 'app-grade-form',
  imports: [],
  templateUrl: './grade-form.component.html',
  styleUrl: './grade-form.component.css'
})
export class GradeFormComponent {
  @Input() student!:Student[];
  @Output() onDelete = new EventEmitter<number>()
}
