import { TestBed } from '@angular/core/testing';

import { GradeCalculatorServiceService } from './grade-calculator-service.service';

describe('GradeCalculatorServiceService', () => {
  let service: GradeCalculatorServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GradeCalculatorServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
