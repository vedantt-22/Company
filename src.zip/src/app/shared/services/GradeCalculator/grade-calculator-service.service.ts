import { Injectable } from '@angular/core';
import { Grade } from '../../studentModals';
@Injectable({
  providedIn: 'root'
})
export class GradeCalculatorServiceService {
  calculateAverage(grades : Grade[]): number{
    if(!grades || grades.length === 0) return 0;
      const sum = grades.reduce((acc, curr) => acc + curr.score, 0);
      return (sum / grades.length);
  }

  

  getLetterGrade(score: number) {
    if(score >= 90) return 'A';
    if(score >= 80) return 'B';
    if(score >= 70) return 'C';
    if(score >= 60) return 'D';
    else return 'F';
  }

  getStatusIcon(getLetterGrade: string): string {
    switch (getLetterGrade) {
      case 'A': return '🌟';
      case 'B': return '✅';
      case 'C': return '⚠️';
      case 'D': return '📉';
      default: return '🚨';
    }
  }
}
