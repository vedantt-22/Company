import { Injectable } from '@angular/core';
import { Student, Grade } from '../../studentModals';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
  private students: Student[] = [
  {
    id: 1,
    name: 'Alice Henderson',
    email: 'alice.h@university.edu',
    enrollmentDate: new Date('2023-08-15'),
    grades: [
      { subject: 'Math', score: 98, date: new Date() },
      { subject: 'Physics', score: 94, date: new Date() }
    ] // Testing: Top Performer (Grade A / Green)
  },
  {
    id: 2,
    name: 'Marcus Wright',
    email: 'm.wright@university.edu',
    enrollmentDate: new Date('2023-09-01'),
    grades: [
      { subject: 'Biology', score: 82, date: new Date() },
      { subject: 'Chemistry', score: 88, date: new Date() }
    ] // Testing: Above Average (Grade B / Blue)
  },
  {
    id: 3,
    name: 'Sophia Chen',
    email: 'schen@university.edu',
    enrollmentDate: new Date('2023-01-20'),
    grades: [
      { subject: 'History', score: 75, date: new Date() },
      { subject: 'Literature', score: 71, date: new Date() }
    ] // Testing: Average (Grade C / Yellow)
  },
  {
    id: 4,
    name: 'Jordan Smith',
    email: 'jsmith@university.edu',
    enrollmentDate: new Date('2024-02-10'),
    grades: [
      { subject: 'Economics', score: 62, date: new Date() },
      { subject: 'Law', score: 68, date: new Date() }
    ] // Testing: Near Risk (Grade D / Orange)
  },
  {
    id: 5,
    name: 'Elena Rodriguez',
    email: 'elena.r@university.edu',
    enrollmentDate: new Date('2023-11-05'),
    grades: [
      { subject: 'Math', score: 45, date: new Date() },
      { subject: 'Art', score: 55, date: new Date() }
    ] // Testing: "At Risk" (Grade F / Red)
  },
  {
    id: 6,
    name: 'Kevin Park',
    email: 'k.park@university.edu',
    enrollmentDate: new Date('2024-01-15'),
    grades: [] 
    // Testing: Edge Case (No grades yet / Should show 0 or N/A)
  },
  {
    id: 7,
    name: 'Liam Wilson',
    email: 'liam.w@university.edu',
    enrollmentDate: new Date('2023-05-12'),
    grades: [
      { subject: 'Computer Science', score: 100, date: new Date() }
    ] // Testing: Perfect Score
  },
  {
    id: 8,
    name: 'Sarah Connor',
    email: 'sarah.oc@university.edu',
    enrollmentDate: new Date('2023-12-01'),
    grades: [
      { subject: 'Philosophy', score: 89.5, date: new Date() }
    ] // Testing: Decimal rounding in Number Pipe
  },
  {
    id: 9,
    name: 'David Miller',
    email: 'dmiller@university.edu',
    enrollmentDate: new Date('2023-08-22'),
    grades: [
      { subject: 'Math', score: 30, date: new Date() },
      { subject: 'English', score: 40, date: new Date() }
    ] // Testing: Extreme low for stats
  },
  {
    id: 10,
    name: 'Aisha Gupta',
    email: 'agupta@university.edu',
    enrollmentDate: new Date('2023-09-10'),
    grades: [
      { subject: 'Music', score: 91, date: new Date() },
      { subject: 'Sociology', score: 84, date: new Date() }
    ] // Testing: Mixed A and B
  }
  ];
  private nextId = 11;
  getStudents(){
    return this.students;
  }
  getStudentById(id: number): Student | undefined {
    return this.students.find(s => s.id === id);
  }
// Old version name: addStudents (plural)
// New version name: addStudent (singular) - Matches your component call
addStudent(name: string, email: string, enrollmentDate: Date) {
  this.students.push({
    id: this.nextId++, // 1. We use the internal ID counter
    name: name,
    email: email,
    enrollmentDate: enrollmentDate,
    grades: []         // 2. We initialize the grades as an empty array automatically
  });
}
  
  addGrade(studentId: number, grade: Grade) {
    const index = this.students.findIndex(s => s.id === studentId);
    if (index !== -1) {
      this.students[index].grades.push(grade);
    }
  }
  deleteStudent(id: number) {
    const index = this.students.findIndex(s => s.id === id);
    if (index !== -1) {
      this.students.splice(index, 1); // Mutate array to ensure view updates
    }
  }
}
 