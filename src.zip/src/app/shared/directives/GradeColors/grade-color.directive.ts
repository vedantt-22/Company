import { Directive, OnInit, Renderer2, Input, ElementRef, SimpleChanges, OnChanges } from '@angular/core';

@Directive({
  selector: '[appGradeColor]',
  standalone: true
})
export class GradeColorDirective implements OnChanges {
  @Input('appGradeColor') grade!:number; 
  constructor(private el: ElementRef, private renderer: Renderer2) { }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['grade']) {
      this.updateColor();
    }
  }
  updateColor() {
    let color = 'red';
    if(this.grade >= 90) color = 'green';
    else if(this.grade > 80) color = 'blue';
    else if(this.grade > 70) color = 'yellow';
    else if(this.grade >= 60) color = 'orange';
  
  this.renderer.setStyle(this.el.nativeElement, 'color', color);
  }
}
