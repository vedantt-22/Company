import { Directive, OnInit, Renderer2, Input, ElementRef } from '@angular/core';

@Directive({
  selector: '[appGradeColor]'
})
export class GradeColorDirective implements OnInit {
  @Input('appGradeColor') grade!:number; 
  constructor(private el: ElementRef, private renderer: Renderer2) { }
  ngOnInit() {
    let color = 'red';
    if(this.grade >= 90) color = 'green';
    else if(this.grade > 80) color = 'blue';
    else if(this.grade > 70) color = 'yellow';
    else if(this.grade >= 60) color = 'orange';
  
  this.renderer.setStyle(this.el.nativeElement, 'color', color);
  }
}
