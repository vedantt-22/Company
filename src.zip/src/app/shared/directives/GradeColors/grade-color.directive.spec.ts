import { GradeColorDirective } from './grade-color.directive';

describe('GradeColorDirective', () => {
  it('should create an instance', () => {
    const directive = new GradeColorDirective();
    expect(directive).toBeTruthy();
  });
});
