import { Pipe, PipeTransform } from '@angular/core';
import { Grade } from '../../studentModals';
import { GradeCalculatorServiceService } from '../../services/GradeCalculator/grade-calculator-service.service';
@Pipe({
  name: 'gpaCalculator',
  standalone: true
})
export class GpaCalculatorPipePipe implements PipeTransform {
  constructor(private GpaCalci: GradeCalculatorServiceService) {}
  transform(grades: Grade[]): number {
    return this.GpaCalci.calculateAverage(grades);
  }

}
