import { GpaCalculatorPipePipe } from './gpa-calculator-pipe.pipe';

describe('GpaCalculatorPipePipe', () => {
  it('create an instance', () => {
    const pipe = new GpaCalculatorPipePipe();
    expect(pipe).toBeTruthy();
  });
});
