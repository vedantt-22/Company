import { Pipe, PipeTransform } from '@angular/core';
import { GradeCalculatorServiceService } from '../../services/GradeCalculator/grade-calculator-service.service';
@Pipe({
  name: 'letterGradePipe'
})
export class LetterGradePipePipe implements PipeTransform {
  constructor(private gradeCalc: GradeCalculatorServiceService) {}
  transform(value: number): string {
    return this.gradeCalc.getLetterGrade(value);
  }

}
