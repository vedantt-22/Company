import { LetterGradePipePipe } from './letter-grade-pipe.pipe';

describe('LetterGradePipePipe', () => {
  it('create an instance', () => {
    const pipe = new LetterGradePipePipe();
    expect(pipe).toBeTruthy();
  });
});
