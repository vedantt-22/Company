import { FilterByPerformancePipePipe } from './filter-by-performance-pipe.pipe';

describe('FilterByPerformancePipePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByPerformancePipePipe();
    expect(pipe).toBeTruthy();
  });
});
