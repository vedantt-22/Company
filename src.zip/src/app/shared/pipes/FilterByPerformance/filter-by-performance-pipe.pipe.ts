import { Pipe, PipeTransform } from '@angular/core';
import { Student } from '../../studentModals';
import { GradeCalculatorServiceService } from '../../services/GradeCalculator/grade-calculator-service.service';
@Pipe({
  name: 'filterByPerformance',
  standalone: true
})
export class FilterByPerformancePipePipe implements PipeTransform {
constructor(private gradeCalc: GradeCalculatorServiceService) {}

  transform(students: Student[], filterType: string): Student[] {
    if (!students || filterType === 'all') {
      return students;
    }
    return students.filter(student => {
      const avg = this.gradeCalc.calculateAverage(student.grades);
      switch (filterType) {
        case 'excellent':
          return avg >= 90;
        case 'good':
          return avg >= 80 && avg < 90;
        case 'average':
          return avg >= 70 && avg < 80;
        case 'poor':
          return avg < 70;
        default:
          return true;
      }
    });
  }

}
