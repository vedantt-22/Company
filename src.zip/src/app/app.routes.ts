import { Routes } from '@angular/router';

// Import the standalone components
import { StudentListComponent } from './student-list/student-list.component';
import { StudentCardComponent } from './student-card/student-card.component';
import { AddStudentComponent } from './add-student/add-student.component';
import { GradeFormComponent } from './grade-form/grade-form.component';
export const routes: Routes = [
  // Default route: Student List (Home)
  { 
    path: '', 
    component: StudentListComponent, 
    title: 'Grade Tracker - Home' 
  },
  
  // Add Student Page
  { 
    path: 'add-student', 
    component: AddStudentComponent, 
    title: 'Add New Student' 
  },
  
  // Student Details (Card) - Requires :id parameter
  { 
    path: 'student/:id', 
    component: StudentCardComponent, 
    title: 'Student Details' 
  },
  
  // Add Grade Form - Requires :id parameter
  { 
    path: 'student/:id/grade', 
    component: GradeFormComponent, 
    title: 'Add Grade' 
  },
  
  // Wildcard route: Redirect unknown URLs to Home
  { 
    path: '**', 
    redirectTo: '' 
  }
];
