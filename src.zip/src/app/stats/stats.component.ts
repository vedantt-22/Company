import { Component, Input, OnChanges, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Grade } from '../shared/studentModals'; // Import Model
import { GradeCalculatorServiceService } from '../shared/services/GradeCalculator/grade-calculator-service.service';// Import Service

@Component({
  selector: 'app-stats',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './stats.component.html',
  styleUrls: ['./stats.component.css']
})

export class StatsComponent implements OnChanges {
  @Input() grades: Grade[] = [];

  average: number = 0;
  highest: number = 0;
  lowest: number = 0;

  // Inject service to use the central calculation logic
  private gradeService = inject(GradeCalculatorServiceService);

  ngOnChanges(): void {
    if (this.grades && this.grades.length > 0) {
      this.calculateStats();
    } else {
      this.resetStats();
    }
  }

  private calculateStats() {
    // Use the shared service for average to ensure consistency
    this.average = this.gradeService.calculateAverage(this.grades);
    
    // Calculate High/Low locally using Math functions
    const scores = this.grades.map(g => g.score);
    this.highest = Math.max(...scores);
    this.lowest = Math.min(...scores);
  }

  private resetStats() {
    this.average = 0;
    this.highest = 0;
    this.lowest = 0;
  }
}