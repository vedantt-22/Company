import { Component, EventEmitter, Input, Output } from '@angular/core';
import { GradeCalculatorServiceService } from '../shared/services/GradeCalculator/grade-calculator-service.service';
import { Student } from '../shared/studentModals';
@Component({
  selector: 'app-student-card',
  imports: [],
  templateUrl: './student-card.component.html',
  styleUrl: './student-card.component.css'
})
export class StudentCardComponent {
  @Input() student!: Student;
  @Output() deleteEvent = new EventEmitter<number>();

  constructor(public gradeCalc: GradeCalculatorServiceService) {}

  onDelete() {
    this.deleteEvent.emit(this.student.id);
  }
}