import { Component, OnInit, inject } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';

// 1. Import Shared Models & Services
import { Student } from '../shared/studentModals';
import { StudentService } from '../shared/services/Students/student.service';

// 2. Import Child Component (Stats)
import { StatsComponent } from '../stats/stats.component';

// 3. Import Custom Directive & Pipe
import { GradeColorDirective } from '../shared/directives/GradeColors/grade-color.directive';
import { LetterGradePipePipe } from '../shared/pipes/LetterGrade/letter-grade-pipe.pipe';
@Component({
  selector: 'app-student-card',
  standalone: true,
  imports: [CommonModule,
    RouterModule,
    GradeColorDirective, LetterGradePipePipe, StatsComponent],
  templateUrl: './student-card.component.html',
  styleUrls: ['./student-card.component.css']
})
export class StudentCardComponent implements OnInit {
 student: Student | undefined;

  // Dependency Injection
  private route = inject(ActivatedRoute);
  private studentService = inject(StudentService);
  private location = inject(Location);

  ngOnInit(): void {
    // 1. Get ID from URL parameters
    const id = Number(this.route.snapshot.paramMap.get('id'));
    
    // 2. Fetch data using the service
    if (id) {
      this.student = this.studentService.getStudentById(id);
    }
  }

  goBack(): void {
    this.location.back();
  }
}