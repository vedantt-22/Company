import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

// Imports from Shared Layer
import { Student } from '../shared/studentModals';
import { GpaCalculatorPipePipe } from '../shared/pipes/GpaCalculator/gpa-calculator-pipe.pipe';
@Component({
  selector: 'app-student-item',
  standalone: true,
  imports: [CommonModule, RouterModule, GpaCalculatorPipePipe],
  templateUrl: './student-item.html',
  styleUrls: ['./student-item.css'],
})
export class StudentItem {
// Input: Receives data from Parent
  @Input({ required: true }) student!: Student;

  // Output: Notifies Parent to delete
  @Output() deleteRequest = new EventEmitter<number>();
  
  // Output: Notifies Parent to navigate (Optional, simpler to use RouterLink generally, but demonstrating Output)
  @Output() viewRequest = new EventEmitter<number>();

  onDelete() {
    // We emit the ID, we do NOT delete it here ourselves
    this.deleteRequest.emit(this.student.id);
  }

  onView() {
    this.viewRequest.emit(this.student.id);
  }
}

